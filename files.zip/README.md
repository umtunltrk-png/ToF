# 🏰 Fortress Fighters — Telegram Mini App

Fomo Fighters ilhamıyla yapılmış, Telegram üzerinden oynanabilen strateji oyunu.

---

## 🎮 Oyun Özellikleri

| Özellik | Açıklama |
|---|---|
| 🏰 Kale Yönetimi | 6 farklı bina inşa et ve yükselt |
| ⚔️ Birlik Sistemi | 4 farklı asker tipi (Kılıçlı, Okçu, Süvari, Mancınık) |
| 🔥 PvE Savaşlar | 6 farklı düşman, güç tabanlı kazanma şansı |
| 🛡️ Klan | Klan üyeleri ve güç sıralaması |
| 📋 Günlük Görevler | Her gün sıfırlanan 4 görev, ödüllü |
| ⏰ Idle Gelir | Çevrimdışıyken bile altın ve yiyecek üretimi |
| 🎚️ Seviye Sistemi | XP biriktir, seviye atla |

---

## 🛠️ Kurulum

### 1. BotFather'dan Bot Oluştur

```
Telegram'da: @BotFather
/newbot
İsim: Fortress Fighters
Username: fortress_fighters_bot (benzersiz olmalı)
→ BOT_TOKEN alacaksın
```

### 2. Mini App Ayarla

```
@BotFather'da:
/newapp
Bot'unu seç
Title: Fortress Fighters
Description: Kalenizi inşa edin, ordu kurun, düşmanları yenin!
URL: https://senin-sunucun.com (frontend klasörü)
```

### 3. Proje Kurulumu

```bash
git clone <repo>
cd fortress-fighters
npm install
```

### 4. Environment Variables

```bash
export BOT_TOKEN="1234567890:ABCdefGHIjklMNOpqrSTUvwxYZ"
export WEBAPP_URL="https://senin-sunucun.com"
export PORT=3000
```

### 5. Frontend Deploy

`frontend/index.html` dosyasını herhangi bir statik hosting'e yükle:
- **Vercel**: `vercel deploy frontend`
- **Netlify**: Sürükle-bırak
- **GitHub Pages**: Repo'ya push et

### 6. Botu Başlat

```bash
# Development (long polling)
npm run dev

# Production (webhook)
npm start
```

---

## 📁 Proje Yapısı

```
fortress-fighters/
├── frontend/
│   └── index.html        ← Oyun arayüzü (tek dosya, tüm JS dahil)
├── bot/
│   └── bot.js            ← Telegram bot (grammy)
├── package.json
└── README.md
```

---

## 🎯 Oyun Mekanikleri

### Bina Sistemi
```
Kale (1-10)     → Diğer binaların max seviyesini belirler
Kışla (1-8)     → Asker eğitimini açar
Çiftlik (1-8)   → Yiyecek üretimi/saat
Maden (1-8)     → Altın üretimi/saat  
Surlar (1-8)    → +Savunma bonusu
Demirci (1-8)   → +Saldırı bonusu
```

### Asker Tipleri
```
Kılıçlı   ATK:10 DEF:8  → Kışla Sv.1
Okçu      ATK:15 DEF:4  → Kışla Sv.1
Süvari    ATK:22 DEF:12 → Kışla Sv.3
Mancınık  ATK:50 DEF:2  → Kışla Sv.5
```

### Savaş Formülü
```
playerPower = Σ(asker * (ATK + DEF)) + surlar*20 + demirci*15
winChance   = playerPower / (playerPower + enemyPower)
winChance   = clamp(5%, 95%)
```

### Idle Gelir
```
goldPerHour = maden.level * 15 + 10
foodPerHour = çiftlik.level * 10 + 5
maxIdleHours = 8  (offline gelir limiti)
```

---

## 🚀 Geliştirme Yol Haritası

- [ ] Backend veritabanı (PostgreSQL / Redis)
- [ ] Gerçek PvP (oyuncu vs oyuncu)
- [ ] Klan savaşları (zamanlı etkinlik)
- [ ] Sezon sistemi + ödül havuzu
- [ ] TON blockchain entegrasyonu
- [ ] Push notification (savaş bitti, yükseltme bitti)
- [ ] Referral sistemi

---

## 📝 Lisans

MIT
